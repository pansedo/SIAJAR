	<div class="mobile-menu-left-overlay"></div>
	<nav class="side-menu side-menu-compact">
	    <ul class="side-menu-list">
	        <li class="blue-dirty opened"> 
	            <a href="index.php">
	                <i class="font-icon font-icon-home active"></i>
	                <span class="lbl">Dashboard</span>
	            </a>
	        </li>
	        <li class="green">
	            <a href="media.php">
	                <i class="font-icon font-icon-doc"></i>
	                <span class="lbl">Media</span>
	            </a>
	        </li>
	        <li class="gold">
	            <a href="kategori.php">
	                <i class="font-icon font-icon-burger"></i>
	                <span class="lbl">Kategori</span>
	            </a>
	        </li>
	        <li class="blue">
	            <a href="pengaduan.php">
	                <i class="glyphicon glyphicon-refresh"></i>
	                <span class="lbl">Pengaduan</span>
	            </a>
	        </li>
	        <!-- <li class="blue">
	            <a href="#">
	                <i class="font-icon font-icon-users"></i>
	                <span class="lbl">Pengaduan Media</span>
	            </a>
	        </li>
	        <li class="purple">
	            <a href="#">
	                <i class="font-icon font-icon-comments"></i>
	                <span class="lbl">Users Report</span>
	            </a>
	        </li> -->
	        <li class="red">
	            <a href="../Auth/logout.php">
	                <span class="font-icon font-icon-refresh-2"></span>
	                <span class="lbl">Logout</span>
	            </a>
	        </li>
	    </ul>
	</nav><!--.side-menu-->		