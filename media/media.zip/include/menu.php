<nav class="side-menu">
	    <ul class="side-menu-list">
	        <li class="blue with-sub">
	            <a href="">
	                <i class="fa fa-graduation-cap"></i>
	                <span class="lbl">Sekolah Menengah Kejuruan</span>
	            </a>
	        </li>
	        <li class="blue with-sub">
	            <a href="">
	                <i class="fa fa-graduation-cap"></i>
	                <span class="lbl">Sekolah Menengah Atas</span>
	            </a>
	        </li>
	        <li class="blue with-sub">
	            <a href="">
	                <i class="fa fa-graduation-cap"></i>
	                <span class="lbl">Sekolah Menengah Pertama</span>
	            </a>
	        </li>
	        <li class="blue with-sub">
	            <a href="">
	                <i class="fa fa-graduation-cap"></i>
	                <span class="lbl">Sekolah Dasar</span>
	            </a>
	        </li>
	       
	    </ul>
	</nav><!--.side-menu-->