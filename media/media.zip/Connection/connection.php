 <?php
	
	$mongo = new MongoClient('127.0.0.1:27017');
	$db =  $mongo->siajar_lms;

 ?> 